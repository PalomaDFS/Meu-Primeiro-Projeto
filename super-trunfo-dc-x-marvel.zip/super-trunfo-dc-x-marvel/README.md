# Super Trunfo DC x Marvel

A Pen created on CodePen.io. Original URL: [https://codepen.io/PalomaDFS/pen/abQpjPO](https://codepen.io/PalomaDFS/pen/abQpjPO).

Primeiro projeto criado a partir da Imersão da Alura 2021