var cartaNumeroUm = {
  nome: "Super Homem",
  imagem:
    "https://www.magazine-hd.com/apps/wp/wp-content/uploads/2014/07/movies-henry-cavill-batman-v-superman-dawn-of-justice-hi-res.jpg",
  atributos: {
    ataque: 100,
    defesa: 90,
    magia: 70
  }
};

var cartaNumeroDois = {
  nome: "Viúva Negra",
  imagem:
    "https://claudia.abril.com.br/wp-content/uploads/2020/01/black-widow.jpg",
  atributos: {
    ataque: 60,
    defesa: 60,
    magia: 10
  }
};

var cartaNumeroTres = {
  nome: "Hulk",
  imagem:
    "https://tse1.mm.bing.net/th?id=OIP.C-foSUsyqmE2ap0baIZGhwHaHa&pid=Api&rs=1&c=1&qlt=95&h=180",
  atributos: {
    ataque: 100,
    defesa: 90,
    magia: 30
  }
};

var cartaNumeroQuatro = {
  nome: "Batman",
  imagem:
    "https://img.r7.com/images/batman-affleck1-07022019104625087?dimensions=660x360&&&&&&&resize=660x360&crop=717x391+0+0",
  atributos: {
    ataque: 70,
    defesa: 60,
    magia: 40
  }
};

var cartaNumeroCinco = {
  nome: "Capitão América",
  imagem: "https://www.coledecore.com.br/wp-content/uploads/2017/11/7-1.jpg",
  atributos: {
    ataque: 75,
    defesa: 75,
    magia: 45
  }
};

var cartaNumeroSeis = {
  nome: "Ciborgue",
  imagem:
    "https://quartaparede.s3.us-east-2.amazonaws.com/wp-content/uploads/2019/03/30162948/ciborgue-752x420.jpg",
  atributos: {
    ataque: 80,
    defesa: 90,
    magia: 40
  }
};

var cartaNumeroSete = {
  nome: "Thor",
  imagem:
    "https://i.pinimg.com/originals/c8/87/82/c88782fda3e8b914970a4740c78b2ecf.jpg",
  atributos: {
    ataque: 90,
    defesa: 90,
    magia: 100
  }
};

var cartaNumeroOito = {
  nome: "Mulher Maravilha",
  imagem:
    "https://img.elo7.com.br/product/zoom/2163028/poster-do-filme-mulher-maravilha-50cm-x-70cm-poster.jpg",
  atributos: {
    ataque: 90,
    defesa: 90,
    magia: 100
  }
};

var cartaNumeroNove = {
  nome: "Homem de Ferro",
  imagem:
    "https://observatoriodocinema.uol.com.br/wp-content/uploads/2021/02/homem-de-ferro-tony-divulgacao.jpg",
  atributos: {
    ataque: 90,
    defesa: 90,
    magia: 60
  }
};

var cartaNumeroDez = {
  nome: "Flash",
  imagem:
    "https://cdn2.unrealengine.com/15br-theflash-screenshot-newsheader-1920x1080-0e77cc2ff454.jpg",
  atributos: {
    ataque: 70,
    defesa: 65,
    magia: 75
  }
};

var cartaMaquina;
var cartaJogador;
var cartas = [
  cartaNumeroUm,
  cartaNumeroDois,
  cartaNumeroTres,
  cartaNumeroQuatro,
  cartaNumeroCinco,
  cartaNumeroSeis,
  cartaNumeroSete,
  cartaNumeroOito,
  cartaNumeroNove,
  cartaNumeroDez
];
var pontosJogador = 0;
var pontosMaquina = 0;

atualizaPlacar();
atualizaQuantidadeDeCartas();

function atualizaQuantidadeDeCartas() {
  var divQuantidadeCartas = document.getElementById("quantidade-cartas");
  var html = " Quantidade de cartas no jogo: " + cartas.length;

  divQuantidadeCartas.innerHTML = html;
}

function atualizaPlacar() {
  var divPlacar = document.getElementById("placar");
  var html = "Jogador " + pontosJogador + " / " + pontosMaquina + " Máquina";

  divPlacar.innerHTML = html;
}

function sortearCarta() {
  var numeroCartaMaquina = parseInt(Math.random() * cartas.length);
  cartaMaquina = cartas[numeroCartaMaquina];
  cartas.splice(numeroCartaMaquina, 1);

  var numeroCartaJogador = parseInt(Math.random() * cartas.length);
  cartaJogador = cartas[numeroCartaJogador];
  cartas.splice(numeroCartaJogador, 1);

  document.getElementById("btnSortear").disabled = true;
  document.getElementById("btnJogar").disabled = false;

  exibeCartaJogador();
}

function exibeCartaJogador() {
  var divCartaJogador = document.getElementById("carta-jogador");
  var moldura =
    '<img src="https://www.alura.com.br/assets/img/imersoes/dev-2021/card-super-trunfo-transparent.png" style=" width: inherit; height: inherit; position: absolute;">';
  divCartaJogador.style.backgroundImage = `url(${cartaJogador.imagem})`;
  var nome = `<p class="carta-subtitle">${cartaJogador.nome}</p>`;
  var opcoesTexto = "";

  for (var atributo in cartaJogador.atributos) {
    opcoesTexto +=
      "<input type='radio' name='atributo' value='" +
      atributo +
      "'>" +
      atributo +
      " " +
      cartaJogador.atributos[atributo] +
      "<br>";
  }

  var html = "<div id='opcoes' class='carta-status'>";

  divCartaJogador.innerHTML = moldura + nome + html + opcoesTexto + "</div>";
}

function obtemAtributoSelecionado() {
  var radioAtributo = document.getElementsByName("atributo");
  for (var i = 0; i < radioAtributo.length; i++) {
    if (radioAtributo[i].checked) {
      return radioAtributo[i].value;
    }
  }
}

function jogar() {
  var divResultado = document.getElementById("resultado");
  var atributoSelecionado = obtemAtributoSelecionado();

  if (
    cartaJogador.atributos[atributoSelecionado] >
    cartaMaquina.atributos[atributoSelecionado]
  ) {
    htmlResultado = '<p class="resultado-final">Venceu</p>';
    pontosJogador++;
  } else if (
    cartaJogador.atributos[atributoSelecionado] <
    cartaMaquina.atributos[atributoSelecionado]
  ) {
    htmlResultado = '<p class="resultado-final">Perdeu</p>';
    pontosMaquina++;
  } else {
    htmlResultado = '<p class="resultado-final">Empatou</p>';
  }
  if (cartas.length == 0) {
    alert("Fim de Jogo");
    if (pontosJogador > pontosMaquina) {
      htmlResultado = '<p class="resultado-final">Venceu</p>';
    } else if (pontosMaquina > pontosJogador) {
      htmlResultado = '<p class="resultado-final">Perdeu</p>';
    } else {
      htmlResultado = '<p class="resultado-final">Empatou</p>';
    }
  } else {
    document.getElementById("btnProximaRodada").disabled = false;
  }

  divResultado.innerHTML = htmlResultado;
  document.getElementById("btnJogar").disabled = true;

  atualizaPlacar();
  exibeCartaMaquina();
  atualizaQuantidadeDeCartas();
}

function exibeCartaMaquina() {
  var divCartaMaquina = document.getElementById("carta-maquina");
  var moldura =
    '<img src="https://www.alura.com.br/assets/img/imersoes/dev-2021/card-super-trunfo-transparent.png" style=" width: inherit; height: inherit; position: absolute;">';
  divCartaMaquina.style.backgroundImage = `url(${cartaMaquina.imagem})`;
  var nome = `<p class="carta-subtitle">${cartaMaquina.nome}</p>`;
  var opcoesTexto = "";

  for (var atributo in cartaMaquina.atributos) {
    console.log(atributo);
    opcoesTexto +=
      "<p type='text' name='atributo' value='" +
      atributo +
      "'>" +
      atributo +
      " " +
      cartaMaquina.atributos[atributo] +
      "<br>";
  }

  var html = "<div id='opcoes' class='carta-status --spacing'>";

  divCartaMaquina.innerHTML = moldura + nome + html + opcoesTexto + "</div>";
}

function proximaRodada() {
  var divCartas = document.getElementById("cartas");

  divCartas.innerHTML = `<div id="carta-jogador" class="carta"></div> <div id="carta-maquina" class="carta"> </div>`;

  document.getElementById("btnSortear").disabled = false;
  document.getElementById("btnJogar").disabled = true;
  document.getElementById("btnProximaRodada").disabled = true;

  var divResultado = document.getElementById("resultado");
  divResultado.innerHTML = "";
}
